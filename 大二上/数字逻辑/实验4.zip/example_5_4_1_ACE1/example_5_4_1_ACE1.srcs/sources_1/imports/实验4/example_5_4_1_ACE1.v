`timescale 1ns / 1ps

module example_5_4(
    input cp,
    input x,
    input y1, y2, y3,
    output reg ny1, ny2, ny3, z
);

    always @(posedge cp)
    begin
        case({x, y3, y2, y1})
            0: begin ny3 <= 0; ny2 <= 0; ny1 <= 0; end
            1: begin ny3 <= 0; ny2 <= 1; ny1 <= 0; end	               
            2: begin ny3 <= 1; ny2 <= 0; ny1 <= 0; end	               
            3: begin ny3 <= 1; ny2 <= 1; ny1 <= 0; end	               
            4: begin ny3 <= 0; ny2 <= 0; ny1 <= 0; end	               
            5: begin ny3 <= 0; ny2 <= 1; ny1 <= 0; end	               
            6: begin ny3 <= 1; ny2 <= 0; ny1 <= 0; end
            7: begin ny3 <= 1; ny2 <= 1; ny1 <= 1; end
            8: begin ny3 <= 0; ny2 <= 0; ny1 <= 1; end
            9: begin ny3 <= 0; ny2 <= 1; ny1 <= 1; end	               
            10: begin ny3 <= 1; ny2 <= 0; ny1 <= 1; end	               
            11: begin ny3 <= 1; ny2 <= 1; ny1 <= 1; end	               
            12: begin ny3 <= 0; ny2 <= 0; ny1 <= 1; end	               
            13: begin ny3 <= 0; ny2 <= 1; ny1 <= 1; end	               
            14: begin ny3 <= 1; ny2 <= 0; ny1 <= 1; end
            15: begin ny3 <= 1; ny2 <= 1; ny1 <= 1; end
        endcase
        z <= ny3 ^ ny2 ^ ny1; 
    end
endmodule

module example_5_4_exe (    
    input [7:0] sw_pin,
    input btn_1,
    output [7:0] led_pin
);
    reg y1, y2, y3;
    example_5_4 U(.cp(btn_1), .x(sw_pin[7]), .y1(y1), .y2(y2), .y3(y3), .ny1(led_pin[5]), .ny2(led_pin[6]), .ny3(led_pin[7]), .z(led_pin[0]));
    initial begin
        y1 = 0;
        y2 = 0;
        y3 = 0;
    end

    always @(*)
    begin
        y1 <= led_pin[5];
        y2 <= led_pin[6];
        y3 <= led_pin[7];
    end
    
endmodule