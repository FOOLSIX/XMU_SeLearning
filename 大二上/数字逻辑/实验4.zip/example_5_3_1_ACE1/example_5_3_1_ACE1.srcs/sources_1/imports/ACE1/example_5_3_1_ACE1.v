`timescale 1ns / 1ps	

module example_5_3_1(
    input cp,
    input x1,
    input x2,                            		 	
    input y,	 
    output reg ny, z
);

    always @(posedge cp)
    begin
        z <= x1 ^ x2 ^ y;
        ny <= (x1 & x2) + (x1 & y) + (x2 & y);
    end

endmodule