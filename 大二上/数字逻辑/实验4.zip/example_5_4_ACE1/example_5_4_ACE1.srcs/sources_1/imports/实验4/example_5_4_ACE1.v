`timescale 1ns / 1ps	

module xor_gate (
    input a,
    input b,
    output f
);
    reg y;
    always @(a, b) 
    begin
        y <= a ^ b;
    end
    assign f = y;
endmodule

module clk_t_flip_flop (
    input t,
    input cp,
    output reg q
);

    always @(posedge cp)
    begin
        case(t)
            1: q <= ~q;
        endcase
    end

endmodule

module example_5_4_1 (
    input cp,
    input x,
    input y1, y2, y3,
    output ny1, ny2, ny3, z
);
    wire t1, t2, t3, y3_xor_y2;
    xor_gate U1(.a(y1), .b(x), .f(t1));
    xor_gate U2(.a(y1), .b(y2), .f(t2));
    xor_gate U3(.a(y2), .b(y3), .f(t3));
    clk_t_flip_flop U4(.t(t1), .cp(cp), .q(ny1));
    clk_t_flip_flop U5(.t(t2), .cp(cp), .q(ny2));
    clk_t_flip_flop U6(.t(t3), .cp(cp), .q(ny3));
    xor_gate U7(.a(ny3), .b(ny2), .f(y3_xor_y2));
    xor_gate U8(.a(y3_xor_y2), .b(ny1), .f(z));
endmodule

module example_5_4_1_exe (
    input [7:0] sw_pin,
    input btn_1,
    output [7:0] led_pin
);
    
    reg y1, y2, y3;
    example_5_4_1 U(.cp(btn_1), .x(sw_pin[7]), .y1(y1), .y2(y2), .y3(y3), .ny1(led_pin[5]), .ny2(led_pin[6]), .ny3(led_pin[7]), .z(led_pin[0]));
    initial begin
        y1 = 0;
        y2 = 0;
        y3 = 0;
    end

    always @(*)
    begin
        y1 <= led_pin[5];
        y2 <= led_pin[6];
        y3 <= led_pin[7];
    end
    
endmodule