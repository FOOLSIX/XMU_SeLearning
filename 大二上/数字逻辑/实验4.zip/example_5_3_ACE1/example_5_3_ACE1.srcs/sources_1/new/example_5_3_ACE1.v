`timescale 1ns / 1ps

module xor_gate3(
    input a,
    input b,
    input c,
    output f                               
);
    reg y;
    always @(*)
    begin
        y <= a^b^c; 
    end
    assign f = y;
endmodule

module and_gate(
    input a,
    input b,
    output f                               
);
    reg y;
    always @(*)
    begin
        y <= a & b; 
    end
    assign f = y;
endmodule

module or_gate3(
    input a,
    input b,
    input c,
    output f                               
);
    reg y;
    always @(*)
    begin
        y <= a|b|c; 
    end
    assign f = y;
endmodule

module example_5_3_ACE1(
    input cp,	
    input x1,x2,                               		 
    input y,
    output yn,z
    );
    wire w1,w2,w3;

    xor_gate3 U1(.a(x1), .b(x2), .c(y), .f(z));
    and_gate U2(.a(x1), .b(x2), .f(w1));
    and_gate U3(.a(x1), .b(y), .f(w2));
    and_gate U4(.a(x2), .b(y), .f(w3));
    or_gate3 U5(.a(w1), .b(w2), .c(w3), .f(yn));


endmodule
