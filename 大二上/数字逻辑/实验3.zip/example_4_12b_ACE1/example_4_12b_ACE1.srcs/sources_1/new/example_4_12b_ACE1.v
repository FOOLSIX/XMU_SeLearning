`timescale 1ns / 1ps

module not_gate(
    input a,
    output reg f                               
);
    always @(*)                     
    begin
        f <= ~a; 
    end
endmodule

module nor_gate(
    input a,
    input b,
    output reg f                               
);
    always @(*)                     
    begin
        f <= ~(a|b); 
    end
endmodule



module example_4_12b_ACE1(
    input sw_pin[7:0],   
    output [7:0] led_pin        
);
    wire p1, p2, p3, p4;

    not_gate U1(.a(sw_pin[7]),.f(p1));
    nor_gate U2(.a(p1),.b(sw_pin[6]),.f(p2));
    not_gate U3(.a(sw_pin[1]),.f(p3));
    nor_gate U4(.a(p3),.b(sw_pin[0]),.f(p4));
    nor_gate U5(.a(p2),.b(p4),.f(led_pin[7]));
    
endmodule
