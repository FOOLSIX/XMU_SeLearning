`timescale 1ns / 1ps

module example_4_17_1_ACE1(
    input sw_pin[7:0],
    output [7:0] led_pin            
);

    assign led_pin[7] = ((~sw_pin[7] & sw_pin[5]) | (sw_pin[6] & ~sw_pin[5] & sw_pin[4]) | (sw_pin[7] & ~sw_pin[6] & ~sw_pin[5]));

    assign led_pin[0] = ((~sw_pin[7] & sw_pin[5]) | (sw_pin[6] & ~sw_pin[5] & sw_pin[4]) | (sw_pin[7] & ~sw_pin[6] & ~sw_pin[5]) | (~sw_pin[7] & sw_pin[6] & sw_pin[4]) | (sw_pin[7] & ~sw_pin[5] & sw_pin[4]));  

endmodule