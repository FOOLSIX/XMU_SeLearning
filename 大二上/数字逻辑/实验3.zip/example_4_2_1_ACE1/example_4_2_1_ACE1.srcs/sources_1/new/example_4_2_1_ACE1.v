`timescale 1ns / 1ps

module example_4_2_1_ACE1(
    input sw_pin[7:0],            	                   		
    output reg [7:0] led_pin 
    );
    always @(*)					//��Ϊ������ʽ 
    begin
            led_pin[7] <= sw_pin[7] ^ sw_pin[6];//S
            led_pin[6] <=sw_pin[7] & sw_pin[6]; //C
    end
endmodule
