`timescale 1ns / 1ps

module example_4_2_2_ACE1(
    input sw_pin[7:0],            	                   		 //8����������
    output [7:0] led_pin    		 		//8��led��            
);

    assign led_pin[7] = sw_pin[7] ^ sw_pin[6];  
    assign led_pin[6] = sw_pin[7] & sw_pin[6];  
endmodule
