`timescale 1ns / 1ps

module not_gate(
    input a,
    output reg f                               
);
    always @(*)             
    begin
        f <= ~a; 
    end
endmodule

module and3_gate(
    input a,
    input b,
    input c,
    output reg f                               
);
    always @(*)                       
    begin
        f <= (a & b & c); 
    end
endmodule

module or3_gate(
    input a,
    input b,
    input c,
    output reg f                               
);
    always @(*)                       
    begin
        f <= (a | b | c); 
    end
endmodule

module and2_gate(
    input a,
    input b,
    output reg f                               
);
    always @(*)                       
    begin
        f <= (a & b); 
    end
endmodule

module example_4_17_ACE1(
    input sw_pin[7:0],                               		 
    output [7:0] led_pin    		 	  
);
    wire na,nb,nc,p1,p2,p3,f0,p4,p5;
    
    not_gate U1(.a(sw_pin[7]),.f(na));
    and2_gate U2(.a(na),.b(sw_pin[5]),.f(p1));
    not_gate U3(.a(sw_pin[5]),.f(nc));
    and3_gate U4(.a(sw_pin[5]),.b(nc),.c(sw_pin[4]),.f(p2));
    not_gate U5(.a(sw_pin[6]),.f(nb));
    and3_gate U6(.a(sw_pin[7]),.b(nb),.c(nc),.f(p3));
    or3_gate U7(.a(p1),.b(p2),.c(p3),.f(f0));
    or3_gate U8(.a(p1),.b(p2),.c(p3),.f(led_pin[7]));
    and3_gate U9(.a(n1),.b(sw_pin[6]),.c(sw_pin[4]),.f(p4));
    and3_gate U10(.a(sw_pin[7]),.b(nc),.c(sw_pin[4]),.f(p5));
    or3_gate U11(.a(f0),.b(p4),.c(p5),.f(led_pin[0]));

endmodule
