`timescale 1ns / 1ps

module not_gate(
    input a,
    output reg f                               
);
    always @(*)
    begin
        f <= ~a; 
    end
endmodule

module nand_gate(
    input a,
    input b,
    output reg f                               
);
    always @(*)
    begin
        f <= ~(a & b); 
    end
endmodule


module example_4_2_ACE1(
    input sw_pin[7:0],
    output [7:0] led_pin         
    );
    wire p1,p2,p3,p4;
    nand_gate U1(.a(sw_pin[6]),.b(sw_pin[7]),.f(p1));
    nand_gate U2(.a(sw_pin[6]),.b(p1),.f(p2));
    nand_gate U3(.a(sw_pin[7]),.b(p1),.f(p3));
    nand_gate U4(.a(p2),.b(p3),.f(led_pin[7]));
    not_gate U5(.a(p1),.f(led_pin[6]));

endmodule
