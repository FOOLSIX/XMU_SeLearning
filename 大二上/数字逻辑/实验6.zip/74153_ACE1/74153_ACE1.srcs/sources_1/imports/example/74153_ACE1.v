`timescale 1ns / 1ps

module MUX_74153 (
    input G ,
    input A1, A0,
    input D0, D1, D2, D3,
    output Y
);


assign Y = G ? 0 : (A1 ? (A0 ? D3 : D2) : (A0 ? D1 : D0));

endmodule


module MUX_74153_exe (
    input sw_pin[7:0],
    output [7:0] led_pin
);

MUX_74153 U1 (.G(sw_pin[7]), .A1(sw_pin[6]), .A0(sw_pin[5]), .D0(sw_pin[0]), .D1(sw_pin[1]), .D2(sw_pin[2]), .D3(sw_pin[3]), .Y(led_pin[7]));

endmodule