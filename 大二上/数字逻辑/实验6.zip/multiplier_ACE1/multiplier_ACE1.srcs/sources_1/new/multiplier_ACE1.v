`timescale 1ns / 1ps	

module and_gate(
    input a,
    input b,
    output reg f                               
);
    always @(*)
    begin
        f <= a & b; 
    end
endmodule


module ttl74283 (
    input a4, a3, a2, a1,  
    input b4, b3, b2, b1,  
    input ci,              
    output f4, f3, f2, f1,  
    output co               
);

    wire g1, g2, g3, g4;
    wire p1, p2, p3, p4;
    wire c1, c2, c3, c4;

    assign g1 = a1 & b1;
    assign p1 = a1 ^ b1;
    assign g2 = a2 & b2;
    assign p2 = a2 ^ b2;
    assign g3 = a3 & b3;
    assign p3 = a3 ^ b3;
    assign g4 = a4 & b4;
    assign p4 = a4 ^ b4;

    assign c1 = g1 | (p1 & ci);
    assign c2 = g2 | (p2 & g1) | (p2 & p1 & ci);
    assign c3 = g3 | (p3 & g2) | (p3 & p2 & g1) | (p3 & p2 & p1 & ci);
    assign c4 = g4 | (p4 & g3) | (p4 & p3 & g2) | (p4 & p3 & p2 & g1) | (p4 & p3 & p2 & p1 & ci);

    assign f1 = a1 ^ b1 ^ ci;
    assign f2 = a2 ^ b2 ^ c1;
    assign f3 = a3 ^ b3 ^ c2;
    assign f4 = a4 ^ b4 ^ c3;

    assign co = c4;

endmodule
module multiplier_ACE1(
    input x0,x1,x2,x3,y0,y1,y2,y3,
    output z0,z1,z2,z3,z4,z5,z6,z7
    );
    wire and1,and2,and3,and4,and5,and6,and7,and8,and9,and10,and11,and12,and13,and14,and15,f12,f13,f14,f22,f23,f24,co1,co2;

    and_gate U0(.a(x0),.b(y0),.f(z0));
    and_gate U1(.a(x1),.b(y0),.f(and1));
    and_gate U2(.a(x2),.b(y0),.f(and2));
    and_gate U3(.a(x3),.b(y0),.f(and3));
    and_gate U4(.a(x0),.b(y1),.f(and4));
    and_gate U5(.a(x1),.b(y1),.f(and5));
    and_gate U6(.a(x2),.b(y1),.f(and6));
    and_gate U7(.a(x3),.b(y1),.f(and7));
    and_gate U8(.a(x0),.b(y2),.f(and8));
    and_gate U9(.a(x1),.b(y2),.f(and9));
    and_gate U10(.a(x2),.b(y2),.f(and10));
    and_gate U11(.a(x3),.b(y2),.f(and11));
    and_gate U12(.a(x0),.b(y3),.f(and12));
    and_gate U13(.a(x1),.b(y3),.f(and13));
    and_gate U14(.a(x2),.b(y3),.f(and14));
    and_gate U15(.a(x3),.b(y3),.f(and15));
    ttl74283 U16(.a1(and4),.a2(and5),.a3(and6),.a4(and7),.b1(and1),.b2(and2),.b3(and3),.b4(0),.ci(0),.f1(z1),.f2(f12),.f3(f13),.f4(f14),.co(co1));
    ttl74283 U17(.a1(and8),.a2(and9),.a3(and10),.a4(and11),.b1(f12),.b2(f13),.b3(f14),.b4(co1),.ci(0),.f1(z2),.f2(f22),.f3(f23),.f4(f24),.co(co2));
    ttl74283 U18(.a1(f22),.a2(f23),.a3(f24),.a4(co2),.b1(and12),.b2(and13),.b3(and14),.b4(and15),.ci(0),.f1(z3),.f2(z4),.f3(z5),.f4(z6),.co(z7));
    
endmodule

module multiplier_ACE1_exe(
    input sw_pin[7:0],                   
    output [7:0] led_pin    		 		
);
    multiplier_ACE1 U(.x0(sw_pin[0]),.x1(sw_pin[1]),.x2(sw_pin[2]),.x3(sw_pin[3]),.y0(sw_pin[4]),.y1(sw_pin[5]),.y2(sw_pin[6]),.y3(sw_pin[7]),.z0(led_pin[0]),.z1(led_pin[1]),.z2(led_pin[2]),.z3(led_pin[3]),.z4(led_pin[4]),.z5(led_pin[5]),.z6(led_pin[6]),.z7(led_pin[7]));
    

endmodule