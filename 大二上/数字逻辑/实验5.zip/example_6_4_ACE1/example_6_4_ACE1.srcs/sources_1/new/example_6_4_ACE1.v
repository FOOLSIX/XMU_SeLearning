`timescale 1ns / 1ps

module and_gate(
    input a,
    input b,
    input c,
    input d,
    output f                               
);
    reg y;
    always @(*)
    begin
        y <= a & b & c & d; 
    end
    assign f = y;
endmodule

module t_flip_flop(
    input t,                               	  
    input cp,                                                         
    output q, qn		
);
    reg y;
    always @(negedge cp)
    begin
                case(t)
	               1: y <= ~y;
                endcase
    end
    assign  q= y;
    assign qn = ~y;
endmodule


module example_6_4_ACE1(
    input x,                               		 
    input y3, y2, y1,				
    output ny3, ny2, ny1, z    
    );

    wire ny3n, ny2n, ny1n;

    t_flip_flop U1(.t(1),.cp(x),.q(y1),.qn(ny1n));
    t_flip_flop U2(.t(1),.cp(y1),.q(y2),.qn(ny2n));
    t_flip_flop U3(.t(1),.cp(y2),.q(y3),.qn(ny3n));
    and_gate U4(.a(x),.b(y1),.c(y2),.d(y3),.f(z));

endmodule

module example_6_4_ACE1_exe(
    input btn_1,
    output [7:0] led_pin
);
    reg y3, y2, y1;
    example_6_4_ACE1 U(.x(btn_1),.y3(y3), .y2(y2), .y1(y1),.ny3(led_pin[7]), .ny2(led_pin[6]), .ny1(led_pin[5]), .z(led_pin[0]));
    initial begin
        y3=0;
        y2=0;
        y1=0;
    end
    always @(*)
    begin
	y3 <= led_pin[7];
	y2 <= led_pin[6];
    y1 <= led_pin[5];
    end
endmodule