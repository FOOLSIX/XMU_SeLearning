`timescale 1ns / 1ps

module example_6_11_3_ACE1 (
    input x1, x2,
    input y1, y2,
    output reg ny1, ny2, z
);
    always @(*)
    begin
	if(x2==0 & x1==0) begin
                        case({y2, y1})
	                0: begin ny2 <= 0; ny1 <= 0; z <= 0; end
	                1: begin ny2 <= 1; ny1 <= 1; z <= 0; end
	                3: begin ny2 <= 1; ny1 <= 1; z <= 0; end
	                2: begin ny2 <= 0; ny1 <= 0; end
                        endcase
                end

	if(x2==0 & x1==1) begin
                        case({y2, y1})
	                0: begin ny2 <= 0; ny1 <= 1; z <= 0; end
	                1: begin ny2 <= 0; ny1 <= 1; z <= 0; end
                        endcase
                end

	if(x2==1 & x1==1) begin
                        case({y2, y1})
	                0: begin ny2 <= 0; ny1 <= 1; z <= 0; end
	                1: begin ny2 <= 0; ny1 <= 1; z <= 0; end
                        endcase
                end

	if(x2==1 & x1==0) begin
                        case({y2, y1})
	                0: begin ny2 <= 0; ny1 <= 0; z <= 0; end
	                1: begin ny2 <= 0; ny1 <= 1; z <= 0; end
	                3: begin ny2 <= 1; ny1 <= 0; end
	                2: begin ny2 <= 1; ny1 <= 0; z <= 1; end
                        endcase
                end
    end
endmodule