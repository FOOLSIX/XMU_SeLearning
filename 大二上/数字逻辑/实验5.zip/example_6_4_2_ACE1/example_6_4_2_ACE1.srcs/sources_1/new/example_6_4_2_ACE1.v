`timescale 1ns / 1ps

module and_gate(
    input a,
    input b,
    input c,
    input d,
    output f                               
);
    reg y;
    always @(*)
    begin
        y <= a & b & c & d; 
    end
    assign f = y;
endmodule

module t_flip_flop(
    input t,preq,                       	  
    input cp,                                                         
    output q, qn		
);
    reg y;
    always @(negedge cp)
    begin
                case(t)
                   0:y  <= preq;
	               1: y <= ~preq;
                endcase
    end
    assign  q= y;
    assign qn = ~y;
endmodule


module example_6_4_2_ACE1(
    input x,                               		 
    input y3, y2, y1,				
    output reg ny3, ny2, ny1, z
    );

    wire ny3n, ny2n, ny1n;

    t_flip_flop U1(.t(1),.preq(y1),.cp(x),.q(ny1),.qn(ny1n));
    t_flip_flop U2(.t(1),.preq(y2),.cp(y1),.q(ny2),.qn(ny2n));
    t_flip_flop U3(.t(1),.preq(y3),.cp(y2),.q(ny3),.qn(ny3n));
    and_gate U4(.a(x),.b(y1),.c(y2),.d(y3),.f(z));

endmodule
