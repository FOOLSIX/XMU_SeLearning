`timescale 1ns / 1ps

module nand_gate_2 (
  input a, b,
  output reg f
);

  always @(a, b) begin
    f = ~(a & b);
  end

endmodule

module nand_gate_3 (
  input a, b, c,
  output reg f
);

  always @(a, b, c) begin
    f = ~(a & b & c);
  end

endmodule


module not_gate (
  input a,
  output reg f
);

  always @(a) begin
    f = ~a;
  end

endmodule

module example_6_11_ACE1 (
    input x1, x2,
    input y1, y2,
    output ny1, ny2, z
);
    wire nx1, nx2, t1, t2, t3, t4;
    not_gate U1(.a(x1), .f(nx1));
    not_gate U2(.a(x1), .f(nx2));
    nand_gate_2 U3(.a(x2), .b(y2), .f(t1));

    not_gate U4(.a(t1), .f(z));
    nand_gate_3 U5(.a(nx2), .b(nx1), .c(y1), .f(t2));
    nand_gate_2 U6(.a(t1), .b(y1), .f(t3));

    nand_gate_2 U7(.a(t3), .b(nx1), .f(ny1));
    nand_gate_2 U8(.a(t1), .b(t2), .f(ny2));
endmodule

module example_6_11_ACE1_exe (
    input btn_1,
    input sys_clk_in,
    output [7:0] led_pin
);
    
    reg y1, y2;
    example_6_11_ACE1 U(.x1(btn_1), .x2(sys_clk_in), .y1(y1), .y2(y2), .ny1(led_pin[6]), .ny2(led_pin[7]), .z(led_pin[0]));
    initial 
    begin
        y1 = 0;
        y2 = 0;
    end

    always @(*) begin
        y1 <= led_pin[6];
        y2 <= led_pin[7];
    end
    
endmodule